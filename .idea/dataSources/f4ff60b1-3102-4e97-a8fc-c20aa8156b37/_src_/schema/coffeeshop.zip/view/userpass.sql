CREATE VIEW userpass AS
  SELECT (`coffeeshop`.`user`.`username` + `coffeeshop`.`user`.`password`) AS `username + password`
  FROM `coffeeshop`.`user`;
